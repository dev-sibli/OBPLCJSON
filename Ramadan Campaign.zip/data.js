const productData = {
    shopping: [
        {
            id: 1,
            title: "Premium Smart Watch",
            description: "Track your health and stay connected with this premium smart watch.",
            mainImage: "images/belmonte.png",
            thumbnailImage: "images/belmonte.png"
        },
        {
            id: 2,
            title: "Noise Cancelling Headphones",
            description: "Immerse yourself in pure sound with these premium noise-cancelling headphones.",
            mainImage: "images/bayCashback.png",
            thumbnailImage: "images/bayCashback.png"
        },
        {
            id: 1,
            title: "Premium Smart Watch",
            description: "Track your health and stay connected with this premium smart watch.",
            mainImage: "images/Saralifestyle.png",
            thumbnailImage: "images/Saralifestyle.png"
        },
        {
            id: 2,
            title: "Noise Cancelling Headphones",
            description: "Immerse yourself in pure sound with these premium noise-cancelling headphones.",
            mainImage: "images/deshidash.png",
            thumbnailImage: "images/deshidash.png"
        },
        {
            id: 1,
            title: "Premium Smart Watch",
            description: "Track your health and stay connected with this premium smart watch.",
            mainImage: "images/fashionLifestyle.png",
            thumbnailImage: "images/fashionLifestyle.png"
        },
        {
            id: 2,
            title: "Noise Cancelling Headphones",
            description: "Immerse yourself in pure sound with these premium noise-cancelling headphones.",
            mainImage: "images/fashiondiscount.png",
            thumbnailImage: "images/fashiondiscount.png"
        }
    ],
    dining: [
        {
            id: 1,
            title: "Premium Smart Watch",
            description: "Track your health and stay connected with this premium smart watch.",
            mainImage: "images/bogo-1.jpg",
            thumbnailImage: "images/bogo-1.jpg"
        },
        {
            id: 2,
            title: "Noise Cancelling Headphones",
            description: "Immerse yourself in pure sound with these premium noise-cancelling headphones.",
            mainImage: "images/bogo-all.jpg",
            thumbnailImage: "images/bogo-all.jpg"
        }
    ],
    travel: [
        {
            id: 1,
            title: "Hello",
            description: "Track your health and stay connected with this premium smart watch.",
            mainImage: "images/sharetrip-hotel.jpg",
            thumbnailImage: "images/sharetrip-hotel.jpg"
        },
        {
            id: 2,
            title: "Noise Cancelling Headphones",
            description: "Immerse yourself in pure sound with these premium noise-cancelling headphones.",
            mainImage: "https://www.lankabangla.com/wp-content/uploads/2025/02/sme-chairman-greetings.jpg",
            thumbnailImage: "https://www.lankabangla.com/wp-content/uploads/2025/02/sme-chairman-greetings.jpg"
        }
    ],
    hotels: [
        {
            id: 1,
            title: "Premium Smart Watch",
            description: "Track your health and stay connected with this premium smart watch.",
            mainImage: "https://www.lankabangla.com/wp-content/uploads/2025/02/sme-chairman-greetings.jpg",
            thumbnailImage: "https://www.lankabangla.com/wp-content/uploads/2025/02/sme-chairman-greetings.jpg"
        },
        {
            id: 2,
            title: "Noise Cancelling Headphones",
            description: "Immerse yourself in pure sound with these premium noise-cancelling headphones.",
            mainImage: "https://www.lankabangla.com/wp-content/uploads/2025/02/sme-chairman-greetings.jpg",
            thumbnailImage: "https://www.lankabangla.com/wp-content/uploads/2025/02/sme-chairman-greetings.jpg"
        }
    ]
};

export default productData;
